Use files with the API_FORMAT suffix for comfystream, files in workflow_format/ have layout metadata for opening in ComfyUI.
Some workflows in LoRAs/ may use ComfyUI-SAM2-Realtime, and all combine a v1.5 lora with a stablediffusion checkpoint.
